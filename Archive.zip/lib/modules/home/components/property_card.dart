import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:get/get.dart';
import 'package:jaytap/modules/favorites/views/fav_button.dart';
import 'package:jaytap/modules/house_details/models/property_model.dart';
import 'package:jaytap/modules/house_details/views/house_deatil_view/house_details_view.dart';
// 'kartal' ve 'extensions' importları projenizde özel olduğu için
// yerlerinde bıraktım, ancak standart ThemeData kullanımı için bazılarını değiştirdim.
import 'package:kartal/kartal.dart';
import 'package:jaytap/shared/extensions/extensions.dart';

class PropertyCard extends StatelessWidget {
  final PropertyModel property;
  final bool isBig;
  final bool myHouses;

  const PropertyCard({
    super.key,
    required this.property,
    required this.isBig,
    required this.myHouses,
  });

  @override
  Widget build(BuildContext context) {
    final tag = property.category?.titleTk ?? 'Kategorisiz';
    final price = property.price?.toString() ?? 'Bilinmiyor';
    final title = property.name ?? 'Emlak Adı Yok';
    final details = "${property.square?.toString() ?? '?'} m²"; // İsterseniz daha fazla detay ekleyebilirsiniz.
    final location = "${property.village?.name ?? ''}, ${property.region?.name ?? ''}";
    final imageUrl = property.img ?? '';
    final hasMultipleImages = property.imgUrlAnother != null && property.imgUrlAnother!.isNotEmpty;
    final double cardBorderRadius = isBig ? 12.0 : 8.0;
    final double titleFontSize = isBig ? 18 : 15;
    final double priceFontSize = isBig ? 22 : 18;
    final double locationFontSize = isBig ? 14 : 12;
    final double locationIconSize = isBig ? 18 : 15;

    return GestureDetector(
      onTap: () {
        Get.to(() => HouseDetailsView(houseID: property.id, myHouses: myHouses));
      },
      // Yandex'teki gibi temiz bir kart görünümü için Card widget'ı kullanıyoruz.
      child: Card(
        margin: EdgeInsets.zero, // Dış boşluğu kaldır
        elevation: 2,
        shadowColor: Colors.black.withOpacity(0.1),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(cardBorderRadius),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- GÖRSEL ALANI ---
            _buildImageSection(
              context,
              cardBorderRadius,
              hasMultipleImages,
              imageUrl,
              tag,
            ),

            // --- BİLGİ ALANI ---
            _buildInfoSection(
              context,
              price,
              title,
              details,
              location,
              priceFontSize,
              titleFontSize,
              locationFontSize,
              locationIconSize,
            ),
          ],
        ),
      ),
    );
  }

  // Resim bölümünü oluşturan yardımcı metot
  Widget _buildImageSection(
    BuildContext context,
    double borderRadius,
    bool hasMultipleImages,
    String imageUrl,
    String tag,
  ) {
    return AspectRatio(
      aspectRatio: 16 / 14,
      child: ClipRRect(
        borderRadius: BorderRadius.vertical(top: Radius.circular(borderRadius)),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (hasMultipleImages)
              CarouselSlider.builder(
                itemCount: property.imgUrlAnother!.length,
                itemBuilder: (context, itemIndex, pageViewIndex) {
                  return _buildNetworkImage(property.imgUrlAnother![itemIndex]);
                },
                options: CarouselOptions(
                  height: double.infinity,
                  viewportFraction: 1.0,
                  enableInfiniteScroll: false,
                ),
              )
            else
              _buildNetworkImage(imageUrl),

            // Kategori (Arenda/Satlyk) etiketi
            Positioned(
              top: 8,
              left: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  tag,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: tag == "Arenda" ? Colors.deepOrange : Colors.blueAccent,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            // Favori butonu
            Positioned(
              top: 5,
              right: 5,
              child: FavButton(itemId: property.id),
            ),
          ],
        ),
      ),
    );
  }

  // Bilgi bölümünü oluşturan yardımcı metot
  Widget _buildInfoSection(
    BuildContext context,
    String price,
    String title,
    String details,
    String location,
    double priceFontSize,
    double titleFontSize,
    double locationFontSize,
    double locationIconSize,
  ) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Fiyat
          Text(
            "$price TMT",
            style: TextStyle(
              fontSize: priceFontSize,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 4),

          // Başlık ve Detaylar
          Text(
            "$title, $details",
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: titleFontSize,
              color: Colors.black,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),

          // Lokasyon
          Row(
            children: [
              Icon(
                IconlyLight.location, // Yandex'teki metro ikonu yerine lokasyon
                color: Colors.grey.shade600,
                size: locationIconSize,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  location,
                  style: TextStyle(
                    fontSize: locationFontSize,
                    color: Colors.grey.shade700,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Tekrarlanan network image kodunu bir metoda çıkardık
  Widget _buildNetworkImage(String url) {
    return CachedNetworkImage(
      imageUrl: url,
      width: double.infinity,
      fit: BoxFit.cover,
      placeholder: (context, url) => const Center(child: CircularProgressIndicator(strokeWidth: 2.0)),
      errorWidget: (context, url, error) => const Center(child: Icon(IconlyLight.image, color: Colors.grey)),
    );
  }
}
