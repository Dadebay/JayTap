import 'package:flutter/cupertino.dart';

enum ColumnSize { small, medium, large }

@immutable
class StringConstants {
  static const String appName = 'JaýTap';
}
